/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * QLogic Fibre Channel HBA Driver
 * Copyright (c)  2003-2014 QLogic Corporation
 *
 * See LICENSE.qla2xxx for copyright and licensing details.
 */
/*
 * Driver version
 */
#define QLA2XXX_VERSION      "10.02.09.00-k"

#define QLA_DRIVER_MAJOR_VER	10
#define QLA_DRIVER_MINOR_VER	2
#define QLA_DRIVER_PATCH_VER	9
#define QLA_DRIVER_BETA_VER	0
